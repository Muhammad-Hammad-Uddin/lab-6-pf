#include<stdio.h>
main(){
	int a,b,i;
	printf("enter a number");
	scanf("%d",&a);
	printf("enter second number");
	scanf("%d",&b);
	if(a<b){
	 for(i=a;i<=b;i++){
		switch(i){
			case 0:
			 printf("zero");
			 break;
			case 1:
			    printf("one");
			    break;
			case 2:
			    printf("two");
			    break;
			case 3:
			    printf("three");
			    break;
			case 4:
				printf("four");
				break;
			case 5:
				printf("six");
				break;
			case 6:
				printf("seven");
				break;
			case 8:
			    printf("eight");
			    break;
			case 9:
				printf("nine");
				break;
				default:
				if(i%2==0){
					printf("even");
					}
					
				else {
				
				printf("odd");
			}
			break;
			 
				
	}
				
		}
		
	}else
	printf("the first number cannot be greater");
	
}
