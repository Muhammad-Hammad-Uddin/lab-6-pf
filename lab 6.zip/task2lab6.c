#include<stdio.h>
main(){
int sum=1,su=0,i,x;

int a=1;
int b=1;
for(i=1;i<=20;i++){
	if (i%3==0||i%5==0||i%7==0);
	su+=i;
	
	sum=a+b;
	a=b;
	b=sum;
	
}
printf("the sum is %d",su);
}
