#include<stdio.h>
main()
{
	int a;
	printf("enter size of an array");
	scanf("%d",&a);
	
int sum=0;
int i;
int  numbers[a];
for (i=0;i<=a;i++){
	printf("enter numbers");
	scanf("%d",&numbers[i]);}
	for(i=0;i<=a;i++){
	sum+=numbers[i];
	
}
printf("total sum of array  is %d",sum);
}
