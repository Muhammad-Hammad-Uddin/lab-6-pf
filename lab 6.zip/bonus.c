#include<stdio.h>
main(){
	int fizz=0,a,b,buzz=0,i,fizzbuzz=0;
	printf("enter starting number\n");
	scanf("%d",&a);
	printf("enter ending number\n");
	scanf("%d",&b);
	for (i=a;i<=b;i++){
		if(i%3==0&&i%5==0)
		fizzbuzz++;
	    if (i%3==0)
		fizz++;
		if (i%5==0)
		buzz++;
		
	}
	printf("fizz-buzz=%d\n",fizzbuzz);
	printf("fizz=%d\n",fizz);
	printf("buzz=%d\n",buzz);

	


}
	


