#include<stdio.h>
main(){
	int n,i,a;
	printf("enter size of an array");
	scanf("%d",&a);
	int numbers[a];
	for (i=0;i<a;i++){
	printf("enter numbers");
	scanf("%d",&numbers[i]);}
	int Maximum = numbers[0];
	int Minimum = numbers[0];
	for(i=1;i<a;i++){
	
		if (Maximum < numbers[i])
		{
			Maximum = numbers[i];
		}
		if (Minimum > numbers[i]){
			Minimum=numbers[i];
		}
    }
    printf("the maximum number is %d\n",Maximum);
    printf("the minimum number is %d",Minimum);
}
