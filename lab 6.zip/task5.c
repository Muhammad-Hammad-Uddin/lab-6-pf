#include<stdio.h>
main(){
	int a=0,i;
	int b=1;
	for(i=1;i<=7;i++){
	
	if(i%2!=0){
	
	printf("%d %d %d %d\n",a,a,a,a);
	a+=2;}
	else{
	printf("  %d %d \n",b,b);
		b+=2;
		
	}
}
}
