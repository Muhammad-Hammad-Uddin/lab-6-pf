#include<stdio.h>
main(){

   int a,b,gcd,i,c;
    printf("enter number 1  ");
    scanf("%d",&a);
    printf("enter number 2");
    scanf("%d",&b);
    for(i=1;i<=a&&i<=b;i++){
     if(a%i==0&&b%i==0){
     	
    gcd=i;
 }

    
    
    }
    c=a*b/gcd;
    printf("the gcd is %d",gcd);
    printf("the lcm is %d",c);
}  
