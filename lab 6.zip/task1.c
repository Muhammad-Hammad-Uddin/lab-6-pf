#include<stdio.h>
main(){
	int a,c,b=0,i;
	printf("enter a number");
	scanf("%d",&a);
	for(i=a-1;i>=1;i--){
		if(a%i==0)
	b+=i;
	}
	if(b==a)
	printf("%d is a perfect number",a);
	else
	printf("%d is not a perfect number",a);
	
}
