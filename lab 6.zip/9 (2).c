#include<stdio.h>
main(){

int a,i;
printf("enter size of an array");
	scanf("%d",&a);
	int numbers[a];
	for (i=0;i<a;i++){
	printf("enter numbers");
	scanf("%d",&numbers[i]);
	}
	a=a-1;
	for(i=a;i>=0;i--)
	printf("%d,",numbers[i]);
}
